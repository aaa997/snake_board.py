def secret_function():
    print('My username is aaa997 and I know I must read the submission response.')
