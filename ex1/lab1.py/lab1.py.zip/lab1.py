#############################################################
# FILE : lab1.py
# WRITER : achikam_levy , aaa997 , 208764944
# EXERCISE : intro2cs1 lab1 2021
# DESCRIPTION: A simple program that prints "Hello World" to
# the standard output (screen).
#############################################################
print("Hello World!")