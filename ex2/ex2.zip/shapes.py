#################################################################
# FILE : shapes.py
# WRITER : achikam levy , aaa997 , 208764944
# EXERCISE : intro2cs2 ex2 2020
# DESCRIPTION:
# STUDENTS I DISCUSSED THE EXERCISE WITH:
# WEB PAGES I USED:
# NOTES: ...
#################################################################

import math

def shape_area():
    shape = input("Choose shape (1=circle, 2=rectangle, 3=triangle): ")
    if shape == '1' or shape == '2' or shape == '3':
        if shape == '1':
            r = input()
            r = float(r)
            circle_area = r**2*math.pi
            return circle_area
        if shape == '2':
            a = input()
            b = input()
            a,b = float(a), float(b)
            rectangle_area = a*b
            return rectangle_area
        if shape == '3':
            a = input()
            a = float(a)
            triangle_area =((3**0.5)/4)*(a**2)
            return triangle_area
    else:
        return (None)

if __name__ == "__main__":


   print(shape_area())


